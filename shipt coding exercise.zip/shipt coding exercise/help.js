
var webdriver = require('selenium-webdriver');
Keys = require('selenium-webdriver').Keys,
By = require('selenium-webdriver').By,
until = require('selenium-webdriver').until;


// Open Chrome Browser

var driver = new webdriver.Builder().withCapabilities(webdriver.Capabilities.chrome()).build();

// Open google.com

async function test() {

await driver.get('http://www.shipt.com')

await driver.findElement(By.linkText('Help')).click();
await driver.findElement(By.id('search')).sendKeys('shipt');
await driver.findElement(By.id('search')).sendKeys(driver.Keys.ENTER);



}

test();
