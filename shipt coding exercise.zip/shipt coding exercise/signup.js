var webdriver = require('selenium-webdriver');
Keys = require('selenium-webdriver').Keys,
By = require('selenium-webdriver').By,
until = require('selenium-webdriver').until;


// Open Chrome Browser

var driver = new webdriver.Builder().withCapabilities(webdriver.Capabilities.chrome()).build();

// Open google.com

async function test() {

await driver.get('http://www.shipt.com')

await driver.findElement(By.linkText('Sign up')).click();
await driver.findElement(By.id('email')).sendKeys('sudarshanna1989@gmail.com');
await driver.findElement(By.id('zip')).sendKeys('35007');
await driver.findElement(By.className('sc-jhAzac bQSSGO')).click();



}

test();
